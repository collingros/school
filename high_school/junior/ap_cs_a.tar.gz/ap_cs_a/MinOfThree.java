import java.util.Scanner;

public class MinOfThree
{
  public static void main (String[] args)
  {
    int length = 2, MIN_LENGTH = 2;
    
    if (length = MIN_LENGTH)
      System.out.println ("The length is minimal.");
  }
}