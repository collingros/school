public class ShortAnswer2dot2
{
  public static void main (String [] args)
  {
    System.out.print ("Here we go!");
    System.out.println ("12345");
    System.out.print ("Test this if you are not sure.");
    System.out.print ("Another.");
    System.out.println ();
    System.out.println ("All done.");
  }
}
