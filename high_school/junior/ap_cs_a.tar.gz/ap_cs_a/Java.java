public class Java
{
  public static void main (String [] args)
  {
    Color.red
    System.out.println("Hello World!")
    System.out.println("My name is Mr. Computer. I love kids.");
    
  }
}