public class Test
{
  public static void main (String[] args)
  {
    System.out.println ("  CCCCCCCCCCCCCCCCCC          GGGGGGGGGGGGGGGGGG");
    System.out.println ("CCCCCCCCCCCCCCCCCCCC        GGGGGGGGGGGGGGGGGGGG");
    System.out.println ("CCCC                        GGGG");
    System.out.println ("CCCC                        GGGG");
    System.out.println ("CCCC                        GGGG");
    System.out.println ("CCCC                        GGGG          GGGGGGG");
    System.out.println ("CCCCCCCCCCCCCCCCCCCC        GGGGGGGGGGGGGGGGGGGG");
    System.out.println ("  CCCCCCCCCCCCCCCCCC          GGGGGGGGGGGGGGGGGG");
  }
}