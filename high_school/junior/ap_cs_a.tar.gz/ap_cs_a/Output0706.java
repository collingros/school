public class Output0706
{
  public static void main (String[] args)
  {
    int w = 100;
    System.out.println(w);
    qwerty(w);
    System.out.println(w);
  }
  
  
  public static void qwerty(int x)
  {
    x = 50;
    System.out.println(x);
  }
}