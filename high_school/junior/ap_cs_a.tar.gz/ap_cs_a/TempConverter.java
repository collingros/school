public class TempConverter
{
  public static void main (String[] args)
  {
    final int BASE = 32;
    final double CONVERSION_FACTOR = 9.0 / 5.0;
    
    String userInput = new (System.in);
    
    System.out.println ("Enter a number to convert: "+ userInput);
  }
}