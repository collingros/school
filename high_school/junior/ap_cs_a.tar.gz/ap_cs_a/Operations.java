public class Operations
{
  public static void main (String[] args)
  {
    double First = 1.63;
    double Second = 5.36;
    final double Sum = First + Second;
    final double Product = First * Second;
    final double Difference = Second - First;
    System.out.println ( "Sum: "+Sum);
    System.out.println ( "Product: "+Product);
    System.out.println ( "Difference: "+Difference);
  }
}