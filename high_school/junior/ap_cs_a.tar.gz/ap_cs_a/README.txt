first time i was introduced to programming

java

really cool to look back on all of this old stuff

note: some of this i didn't do, but were just examples in the textbook that
i copied to help gain understanding
