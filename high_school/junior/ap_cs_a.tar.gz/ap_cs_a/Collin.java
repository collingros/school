public class Collin
 {
  public static void main (String[] args)
  {
   System.out.println ("Collin Gros");
   System.out.println ("April 27, 1999");
   System.out.println ("Computer Games, Music, Reading");
   System.out.println ("The Wasteland Chronicles");
   System.out.println ("Lord of the Rings: Return of the King");
  }
 }