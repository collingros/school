public class Jim
{
  
  public static void main (String []args)
  {
    System.out.println("A quote by Abraham Lincoln:");
    System.out.println("Whatever you are, be a good one.");
  }
}