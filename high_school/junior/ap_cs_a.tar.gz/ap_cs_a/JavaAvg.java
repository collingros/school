public class JavaAvg
{
  public static void main (String[] args)
  {
    final double AVERAGE = (1 + 2 + 3)/3;
    System.out.println ("Average: "  +AVERAGE);
  }
}