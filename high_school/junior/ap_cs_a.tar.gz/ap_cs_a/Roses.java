public class Roses
{
  public static void main (String [] args)
  {
    System.out.println ("Roses are red, \n\tViolets are blue,\n" +
                        "Sugar is sweet, \n\tBut I have \"commitment issues\", \n\t" +
                        "So I'd rather just be friends\n\tAt this point in our " +
                        "relationship.");
  }
}