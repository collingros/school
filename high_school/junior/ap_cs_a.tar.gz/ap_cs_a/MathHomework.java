public class MathHomework
{
  public static void main (String[] args)
  {
    int n1 = 5;
    System.out.println ("The absolute value of " + n1 + "is: " + Math.abs(n1));
  }
}