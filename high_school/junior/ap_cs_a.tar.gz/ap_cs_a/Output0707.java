public class Output0707
{
  public static void main (String[] args)
  {
    System.out.println(qwerty(100));
  }
  
  public static int qwerty(int x)
  {
    x++;
    return x;
  }
}