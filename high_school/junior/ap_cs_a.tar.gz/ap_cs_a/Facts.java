public class Facts
{
  public static void main (String[] args)
  {
    System.out.println ("We present the following facts for your "
                          + "extracurricular edification:");
    System.out.println ();
    System.out.println ("Letters in the Hawaiian alphabet: 12");
    System.out.println ("Dialing code for Antarctica: " + 672);
    System.out.println ("Year in which Leonardo da Vinci invented "
                          + "the parachute: " + 1515);
    System.out.println ("Speed of ketchup: " + 40 + " km per year");
  }
}